"""Kodi entry point for the movie scraper addon."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Mapping
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs


def _translate_path(path: str) -> str:
    """Return a filesystem path from a Kodi special path."""
    if hasattr(xbmcvfs, "translatePath"):
        return xbmcvfs.translatePath(path)
    return xbmc.translatePath(path)


def _add_project_import_paths(addon_path: str) -> None:
    """Add addon/project paths so packaged scraper modules can be imported."""
    paths = [
        addon_path,
        str(Path(addon_path).parent),
    ]

    for path in paths:
        if path not in sys.path:
            sys.path.insert(0, path)


class CustomMovieDialog(xbmcgui.WindowXMLDialog):
    """Benutzerdefiniertes Fenster für die Filmanzeige."""
    
    def onInit(self):
        # 1. Thumbnail (Image Control - ID 100)
        if hasattr(self, 'thumbnail_url') and self.thumbnail_url:
            self.getControl(100).setImage(self.thumbnail_url)
            
        # 2. Titel (Label Control - ID 200)
        if hasattr(self, 'movie_title') and self.movie_title:
            self.getControl(200).setLabel(self.movie_title)
            
        # 3. Zusammenfassung (TextBox Control - ID 300)
        if hasattr(self, 'movie_summary') and self.movie_summary:
            # Bei Textboxen heißt der Befehl setText statt setLabel
            self.getControl(300).setText(self.movie_summary)

    def onClick(self, controlId):
        # ID 1 ist unser Schließen-Button
        if controlId == 1:
            self.close()


def main() -> None:
    """Run the Kodi addon flow."""
    addon = xbmcaddon.Addon()
    addon_path = _translate_path(addon.getAddonInfo("path"))
    profile_path = _translate_path(addon.getAddonInfo("profile"))
    xbmcvfs.mkdirs(profile_path)
    _add_project_import_paths(addon_path)

    try:
        from database import MovieCacheDatabase
        from wiki_page_request import WikipediaMovieRequester
    except Exception as exc:
        xbmcgui.Dialog().ok("Kodi Movie Scraper Fehler", f"Import-Fehler: {exc}")
        xbmc.log(f"Kodi Movie Scraper import error: {exc}", xbmc.LOGERROR)
        return

    dialog = xbmcgui.Dialog()
    title = dialog.input("Film suchen", type=xbmcgui.INPUT_ALPHANUM)
    if not title:
        return

    try:
        db_path = os.path.join(profile_path, "wikipedia_cache.db")
        cache = MovieCacheDatabase(db_path)
        cache.init_db()
        requester = WikipediaMovieRequester(cache=cache)

        movies = requester.get_movie_infos(title, limit=15)
        if not movies:
            dialog.notification(
                "Kodi Movie Scraper",
                "Kein Film gefunden.",
                xbmcgui.NOTIFICATION_WARNING,
                5000,
            )
            return

        labels = []
        for movie in movies:
            label = movie.title or "Unbekannter Film"
            if movie.wikidata_id:
                label = f"{label} [{movie.wikidata_id}]"
            labels.append(label)

        index = dialog.select("Film auswählen", labels)
        if index < 0:
            return

        selected = movies[index]
        cache.save_movie(title, selected)
        
        # --- Aufruf des benutzerdefinierten XML-Fensters ---
        ui = CustomMovieDialog(
            "script-movie-info.xml", 
            addon_path, 
            "default", 
            "1080i"
        )
        
        # Übergebe ALLE benötigten Daten an die Klasse
        ui.thumbnail_url = selected.thumbnail
        ui.movie_title = selected.title
        ui.movie_summary = selected.summary
        
        # Öffne das Fenster (das Skript pausiert hier, bis das Fenster geschlossen wird)
        ui.doModal() 
        del ui
        
    except Exception as exc:
        xbmcgui.Dialog().ok("Kodi Movie Scraper Fehler", str(exc))
        xbmc.log(f"Kodi Movie Scraper runtime error: {exc}", xbmc.LOGERROR)


if __name__ == "__main__":
    main()